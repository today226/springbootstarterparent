package com.via.config.impl.db;

import java.io.File;

import com.komsco.common.util.IOUtilities;
import com.via.config.Configuration;

public class DBConfig extends Configuration {
	protected File getConfigFile(){
		return IOUtilities.getFileFromClassPath("db/db.properties");
	}
}
